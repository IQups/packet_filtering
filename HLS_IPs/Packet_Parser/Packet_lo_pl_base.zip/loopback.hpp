#ifndef LOOPBACK_H_
#define LOOPBACK_H_

void loopback(
      stream<axiWord> &parser2loopback,
      stream<axiWord> &loopback2merge
      );

#endif // LOOPBACK_H_ not defined

